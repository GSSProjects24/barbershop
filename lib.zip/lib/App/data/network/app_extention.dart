import 'package:flutter/material.dart';





extension StringExtension on String {
  // String get getGenderWidget {
  //   if (this == "male") return AppAsset.male;
  //   return AppAsset.female;
  // }

  String get toCapital {
    return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
  }
}

extension IntegetExtension on int? {
  bool get success {
    if (this == 200 || this == 201 || this == 204) {
      return true;
    }
    return false;
  }
}

extension GeneralExtension<T> on T {
  bool get isEnum {
    final split = toString().split('.');
    return split.length > 1 && split[0] == runtimeType.toString();
  }

  String get getEnumString => toString().split('.').last.toCapital;
}

extension IterableExtension<T> on Iterable<T> {
  Iterable<E> mapWithIndex<E>(E Function(int index, T value) f) {
    return Iterable.generate(length).map((i) => f(i, elementAt(i)));
  }
}

extension MapExtension on Map {
  String get format {
    if (isEmpty) {
      return "";
    } else {
      var firstKey = entries.first.key;
      var mapValues = entries.first.value;
      return "?$firstKey=$mapValues";
    }
  }
}

//Helper functions
void pop(BuildContext context, int returnedLevel) {
  for (var i = 0; i < returnedLevel; ++i) {
    Navigator.pop(context, true);
  }
}

// import 'package:flutter/material.dart';
//
// import 'app_asset.dart';
//
// extension StringExtension on String {
//   String get getGenderWidget {
//     if (this == "male") return AppAsset.male;
//     return AppAsset.female;
//   }
//
//   String get toCapital {
//     return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
//   }
// }
//
// extension GeneralExtension<T> on T {
//   bool get isEnum {
//     final split = toString().split('.');
//     return split.length > 1 && split[0] == runtimeType.toString();
//   }
//
//   String get getEnumString {
//     return toString().split('.').last.toCapital;
//   }
// }
//
// extension IterableExtension<T> on Iterable<T> {
//   Iterable<E> mapWithIndex<E>(E Function(int index, T value) f) {
//     return Iterable.generate(length).map((i) => f(i, elementAt(i)));
//   }
// }
//
// extension MapExtension on Map {
//   String get format {
//     if (isEmpty) {
//       return "";
//     } else {
//       var firstKey = entries.first.key;
//       var mapValues = entries.first.value;
//       return "?$firstKey=$mapValues";
//     }
//   }
// }
//
// //Helper functions
// void pop(BuildContext context, int returnedLevel) {
//   for (var i = 0; i < returnedLevel; ++i) {
//     Navigator.pop(context, true);
//   }
// }
