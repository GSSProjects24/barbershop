class Constants {
  static const baseUrl = baseUrlProd;
  static const baseUrlDev = "https://apibarbershop.graspsoftwaresolutions.xyz/public/api/v1";
  static const baseUrlProd = "https://apibarbershop.graspsoftwaresolutions.xyz/public/api/v1";
  // static const String privacy = "https://website.srisundarajaperumal.com/privacy";
  // static const String terms = "https://website.srisundarajaperumal.com/terms";
  //
  // static const String youtube = "https://youtube.com/@sundararajaperumaltemple9882?si=LoYertp6JSH6QAcK";
  // static const String facebook = "https://www.facebook.com/p/Sri-Sundararaja-Perumal-Temple-Klang-61555715486523/";
  // static const String instgram = "https://www.instagram.com/sspt_klang/";
}