class AppIcons {
  AppIcons._();
  static const shoppingCart = "assets/icons/shopping_cart.png";
  static const dropdownArrow = "assets/icons/dropdown_arrow.png";
  static const iconHome = "assets/icons/home.png";
  static const iconProfile = "assets/icons/profileicon.png";
  static const iconCall = "assets/icons/phonecall.png";
  static const iconBooking = "assets/icons/booking.png";
  static const iconDonation = "assets/icons/donation.png";
  static const iconFestival = "assets/icons/festival.png";
  static const iconHallbooking = "assets/icons/hall_booking.png";
  static const iconList = "assets/icons/list.png";
  static const iconPrasadam = "assets/icons/prasadam.png";
  static const iconPrice = "assets/icons/price.png";
  static const iconService = "assets/icons/service.png";
  static const iconTime = "assets/icons/timetable.png";
  static const iconUbayam = "assets/icons/ubayam.png";
  static const iconUser = "assets/icons/user.png";
  static const iconPlaceholder = "assets/icons/iconPlaceholder.png";
}